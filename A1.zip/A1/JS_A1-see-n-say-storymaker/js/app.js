let nouns = ["dog", "cat", "cow", "sheep"];
let verbs = ["jumps", "runs", "barks", "sleeps"];
let adjectives = ["happy", "sad", "angry", "excited"];
let nouns2 = ["ball", "bone", "stick", "toy"];
let places = ["park", "farm", "home", "zoo"];

let sentence = "";

function addToSentence(word) {
    sentence += word + " ";
    document.getElementById("sentenceDisplay").innerText = sentence;
}

function generateNoun() {
    let randomNoun = nouns[Math.floor(Math.random() * nouns.length)];
    addToSentence(randomNoun);
}

function generateVerb() {
    let randomVerb = verbs[Math.floor(Math.random() * verbs.length)];
    addToSentence(randomVerb);
}

function generateAdjective() {
    let randomAdjective = adjectives[Math.floor(Math.random() * adjectives.length)];
    addToSentence(randomAdjective);
}

function generateNoun2() {
    let randomNoun2 = nouns2[Math.floor(Math.random() * nouns2.length)];
    addToSentence(randomNoun2);
}

function generatePlace() {
    let randomPlace = places[Math.floor(Math.random() * places.length)];
    addToSentence(randomPlace);
}

function speakSentence() {
    let textToSpeak = sentence.trim();
    let utterance = new SpeechSynthesisUtterance(textToSpeak);
    window.speechSynthesis.speak(utterance);
}

function generateRandomStory() {
    resetSentence();
    generateNoun();
    generateVerb();
    generateAdjective();
    generateNoun2();
    generatePlace();
    speakSentence();
}

function resetSentence() {
    sentence = "";
    document.getElementById("sentenceDisplay").innerText = "Your sentence will appear here...";
}
